#include <avr/io.h>
#include <stdio.h>
#define F_CPU 14745600
#include <util/delay.h>

void port_init(void)
{
	interrupt_switch_config();
	led_on();
	led_off();
}
void interrupt_switch_config (void)
{
	DDRJ = DDRJ & 0x7F;  
	PORTJ = PORTJ | 0x80; 
}


void led_on(void)
{
	DDRJ=0x80;
	PORTJ=0x80;
}


void led_off(void)
{
	DDRJ=0x00;
	PORTJ=0x00;
}


int main(void)
{

	while(1)
	{
		if((PINE & 0x80) == 0x80) 
				
			PORTJ = 0x00; 
		else
			
			PORTJ = 0x80; 
	}
}

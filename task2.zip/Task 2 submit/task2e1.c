

#include <avr/io.h>
#include <stdio.h>
#define F_CPU 14745600
#include <util/delay.h>

void port_init(void)
{
     led_on_topfour();
	 led_off_topfour();
	 led_on_bottomfour();
	 led_off_bottomfour();					
}


void led_on_topfour(void)
{

DDRJ=0xFF;
PORTJ=0x0F;
}



void led_off_topfour(void)
{
DDRJ=0xFF;
PORTJ=0x00;
}



void led_on_bottomfour(void)
{
 
 DDRJ=0xFF;
 PORTJ=0xF0;
}


void led_off_bottomfour(void)
{

DDRJ=0xFF;
PORTJ=0x00;
}



int main()
{
	port_init();
	while(1)
	{
		 led_on_topfour(); 
	     
		 _delay_ms(1000);
		  led_off_topfour(); 
	     _delay_ms(1000);
		   
		   led_on_bottomfour();
		  _delay_ms(1000);
		   
		   led_off_bottomfour();
		  _delay_ms(1000);
		 		 
	}
	
} 

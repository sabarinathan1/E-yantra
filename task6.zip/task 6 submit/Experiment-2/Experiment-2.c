/*
*
* File name: Experiment-2
* Description: This experiment is a part of Task 6. It is aimed to get you familiar with whiteline following.
* This experiment involves writing a code to make the robot follow a white line.
  Author: e-Yantra Team
*/

#define __OPTIMIZE__ -O0
#define F_CPU 14745600
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <math.h> //included to support power function
#include "lcd.h"

void port_init();
void timer5_init();
void velocity(unsigned char, unsigned char);
void motors_delay();

/*
*	Global Variable Declaration
*/
// Declare any global variable if you require here

unsigned char ADC_Conversion_wl_sensor(unsigned char);
unsigned char ADC_Value_sharp_sensor;
unsigned char a;
unsigned char ADC_Value;
unsigned char flag = 0;
unsigned char Left_white_line = 0;
unsigned char Center_white_line = 0;
unsigned char Right_white_line = 0;
unsigned char sharp;

///////////////////////////////////LCD initialization ///////////////////////////////
/*
* Function Name: lcd_port_config 
* Input: none
* Output: none
* Logic: Code to initialize desired I/O port using IO port registers 
		 viz. DDRx and PORTx.
Example Call: lcd_port_config 
*/

void lcd_port_config (void)
{
 DDRC = DDRC | 0xF7; // All Port C pins except Pin no. 4 i.e(PC3) have to be set as output.
 PORTC = PORTC & 0x80; // Write suitable value in the PORT C register to make initial values to be "0" 
	 	       //Set initial value as "0" on all pins except Pin no.4 (PC3)
}

//////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////ADC related functions////////////////////////////////////
/*
* Function Name: adc_pin_config 
* Input: none
* Output: none
* Logic: Code to initialize desired I/O port using IO port registers 
		 viz. DDRx and PORTx.
Example Call: adc_pin_config 
*/


void adc_pin_config (void)
{
  DDRF =0x00 ;// All Port F pins have to be set as input.
 PORTF =0x00 ;// Write suitable value in the PORT F register to make initial values to be "0"
 DDRK =0x00 ;//All Port K pins have to be set as input
 PORTK =0x00 ;// Write suitable value in the PORT K register to make initial values to be "0"

}

/*
* Function Name: motion_pin_config 
* Input: none
* Output: none
* Logic: Code to initialize desired I/O port using IO port registers 
		 viz. DDRx and PORTx.
Example Call: motion_pin_config () 
*/

void motion_pin_config (void) 
{
 DDRA =DDRA | 0x0F ;	//  Port A pins(PA3-PA0) have to be set as outputs.
 PORTA =  PORTA & 0xF0;	// Write suitable value in the PORT A register to make initial values to be "0"
 DDRL =  DDRL | 0x18;  	//Setting PL3 and PL4 pins as output for PWM generation
 PORTL =  PORTL | 0x18;	////Write suitable value in the PORT L register to set initial value of the Port L pins (PL3, PL4) to logic 1.
}
//Function to Initialize PORTS
void port_init()
{
	lcd_port_config();
	adc_pin_config();
	motion_pin_config();	
}
 /*
* Function Name: motion_timer5_init 
* Input: none
* Output: none
* Logic: Code to initialize the register to generate the PWM using timer 5 
		 viz. TCCR5A,TCCR5B,TCNT5H,TCNT5L,OCR5AL and OCR5BL
Example Call: motion_timer5_init () 
*/
// Timer 5 initialized in PWM mode for velocity control
// Prescale:256
// PWM 8bit fast, TOP=0x00FF
// Timer Frequency:225.000Hz
void motion_timer5_init()
{
	TCCR5B =0x00 ;	//Stop the timer initially
	TCNT5H =0xFF ;	//Counter higher 8-bit value to which OCR5xL value is compared with
	TCNT5L =0x01 ;	//Counter lower 8-bit value to which OCR5xL value is compared with
	OCR5AL =0xFF ;	//Output compare register low value for Left Motor
	OCR5BL =0xFF ;	//Output compare register low value for Right Motor
	TCCR5A =0xA9 ;	//Write suitable value in this register to override normal port functionality and to select Fast PWM 8-bit Mode.
	
	TCCR5B =0x0B ;	//Write suitable value in this register to set the desired waveform generation mode and to select a prescalar of 64.
	
}
// Function for robot velocity control
/*
* Function Name: velocity
* Input: none
* Output: none
* Logic: Function for robot velocity control
Example Call: velocity (left motor velocity, right motor velocity)
*/
void velocity (unsigned char left_motor, unsigned char right_motor)
{
	OCR5AL = (unsigned char)left_motor;
	OCR5BL = (unsigned char)right_motor;
}
/*
* Function Name: adc_init 
* Input: none
* Output: none
* Logic: Code to initialize the register to generate the PWM using timer 5 
		 viz. ADCSRA,ADCSRB,ADMUX,ACSR
Example Call: adc_init()
*/

void adc_init()
{
ADCSRA =0x00 ;	//Write suitable value in this register to disable ADC during initialization.
	ADCSRB =0x00 ;	//Write suitable value in this register for initialization.
	ADMUX =0x20 ;	//Write appropraite value in the ADMUX register to select external Reference voltage (connected to AREF pin) and left adjustment active.
	ACSR =0x80  ;	//Disable the analog comparator.
	ADCSRA =0x86 ;	//Write suitable value to this register to enable ADC and to select the required prescalar.
	}

/*
* Function Name: ADC_Conversion_wl_sensor 
* Input: ADC Channel number 
* Output: Digital value
* Logic: Code to convert the analog value of the three whiteline sensors into digital value.
Example Call: ADC_Conversion_wl_sensor( ADC channel number) 
*/

//Function For ADC Conversion
unsigned char ADC_Conversion_wl_sensor(unsigned char Ch) 
{
 //This function accepts ADC channel number as an input and returns the digital equivalent of the analog value read by the sensor. 
	unsigned char a;
	if(Ch>7)
	{
		ADCSRB = 0x08;
	}
	Ch = Ch & 0x07;
  	// Complete the code to write appropriate value in the ADMUX register based on the input channel number passed.		
	ADMUX= 0x20| Ch;
	// Start the ADC conversion and return its digital equivalent value.   		
	ADCSRA = ADCSRA | 0x40;		//Set start conversion bit
	while((ADCSRA&0x10)==0);	//Wait for conversion to complete
	a=ADCH;
	ADCSRA = ADCSRA|0x10; //clear ADIF (ADC Interrupt Flag) by writing 1 to it
	ADCSRB = 0x00;
	return a;
}

 /*
* Function Name: ADC_Conversion_sharp_sensor
* Input: none
* Output: none
* Logic: Code to convert the analog value of the front sharp IR range sensor into digital value.
Example Call: ADC_Conversion_sharp_sensor
*/

unsigned char ADC_Conversion_sharp_sensor(unsigned char Ch) 
{

        //front sharp sensor is connected to ADC channel number 11.
	unsigned char a;
	if(Ch>7)
	{
		ADCSRB = 0x08;
	}
	Ch = Ch & 0x23;
        // Complete the code to write appropriate value in the ADMUX register based on the ADC channel number of the front sharp IR range sensor.
        ADMUX= 0x20| Ch;
	// Start the ADC conversion and return its digital equivalent value.   		
	ADCSRA = ADCSRA | 0x40;		//Set start conversion bit
	while((ADCSRA&0x10)==0);	//Wait for conversion to complete
	a=ADCH;
	ADCSRA = ADCSRA|0x10; //clear ADIF (ADC Interrupt Flag) by writing 1 to it
	ADCSRB = 0x00;
	return a;
}


//Function To Print Sesor Values At Desired Row And Coloumn Location on LCD
void print_sensor(char row, char coloumn,unsigned char channel)
{
	
	ADC_Value = ADC_Conversion_wl_sensor(channel);
	lcd_print(row, coloumn, ADC_Value, 3);
}

void print_sharp_sensor(char row, char coloumn,unsigned char channel)
{
	
	ADC_Value_sharp_sensor= ADC_Conversion_sharp_sensor(channel);
	lcd_print(row, coloumn, ADC_Value_sharp_sensor, 3);
}

void forward (void) 
{
  PORTA=0x06;
}
void stop(void)
{
PORTA=0x00;
}
void init_devices (void)
{
 	cli(); //Clears the global interrupts
	port_init();
	adc_init();
	motion_timer5_init();
	sei();   //Enables the global interrupts
}

int main()
{
	   init_devices();
	    lcd_set_4bit();
        lcd_port_config();
        motion_pin_config();
        adc_pin_config();
        adc_init();
        lcd_init();
	
	while(1)
	{
                  //Read the three white line sensor values.

		Left_white_line = ADC_Conversion_wl_sensor(3);	//Getting data of Left WL Sensor
		Center_white_line = ADC_Conversion_wl_sensor(2);	//Getting data of Center WL Sensor
		Right_white_line = ADC_Conversion_wl_sensor(1);	//Getting data of Right WL Sensor
           
                //Read the front sharp sensor value.            
        sharp= ADC_Conversion_sharp_sensor(11);
		flag=0;

		print_sensor(1,1,3);	//Prints value of White Line Sensor1
		print_sensor(1,5,2);	//Prints Value of White Line Sensor2
		print_sensor(1,9,1);
		print_sharp_sensor(2,6,11);	//Prints Value of White Line Sensor3
		 
        //write code to implement white line following algorithm. Refer to the tutorial uploaded on the portal.
  
  //stop the robot if any obstacle is detected within 15 cm distance
  //You can use lcd_print function to print the sensor values for better debugging.
 
         
	if(sharp>=69)
	{
	stop();
	velocity(0,0);
	}
	else
	{	

		if(Center_white_line<0x28)
		{
			flag=1;
			forward();
			velocity(150,150);
		}

		if((Left_white_line>0x28) && (flag==0))
		{
			flag=1;
			forward();
			velocity(100,50);
		}

		if((Right_white_line>0x28) && (flag==0))
		{
			flag=1;
			forward();
			velocity(50,100);
		}

		if(Center_white_line>0x28 && Left_white_line>0x28 && Right_white_line>0x28)
		{
			forward();
			velocity(0,0);
		}
		}

	}
}

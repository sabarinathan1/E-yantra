

#define __OPTIMIZE__ -O0  
#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>


int a;
char result;

char odd_even(unsigned int number)

{
	
	
	if( a%2=0)
	{
	result ='Y'	;//   Output:'Y'(if number is even) 
	}
	
	else
	{
	result ='N'	;	//output : 'N'(if number is odd)
	}
	return result;  
}

/

int main (void)
{
	unsigned char result_value;

	result_value = odd_even(9); // sample function call (Example: for 9 
								//it should return 'N' & for 100 it should return 'Y')
    result_value = odd_even(30);
}
